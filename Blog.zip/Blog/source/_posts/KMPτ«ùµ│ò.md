---
title: KMP算法
tags: [KMP,数据结构]
date: 2018-09-07 15:17:41
permalink: KMP
categories: [数据结构,算法]
description: 
image: https://ws3.sinaimg.cn/large/006tNc79ly1fz1luk0satj31900u04qt.jpg
cover: https://ws3.sinaimg.cn/large/006tNc79ly1fz1luk0satj31900u04qt.jpg
mp3: http://link.hhtjim.com/163/436147067.mp3
---
<p class="description"></p>

<!-- more -->

本文摘自阮一峰的文章，感谢大佬分享。

# **字符串匹配**

## 一. 什么是字符串匹配？

举例说明：有一个字符串“BBC ABCDAB ABCDABCDABDE”，我想知道它里面是否包含字符串“ABCDABD”，这就是字符串匹配问题了。

## 二.kmp发明者

KMP算法的名字也是它算法发明者的名字，[Knuth-Morris-Pratt](https://en.wikipedia.org/wiki/Knuth%E2%80%93Morris%E2%80%93Pratt_algorithm)。它以三个发明者命名，起头那个K就是著名科学家Donald Knuth。

## 三.算法解释

参考国外大神Jake Boxer的文章。

1. ![2018-09-07-bg2013050103](https://ws3.sinaimg.cn/large/006tNc79ly1fz1lvgazdsj30ge042a9x.jpg)

   首先，字符串“BBC ABCDAB ABCDABCDABDE”第一个字符与**搜索词**“ABCDABD”第一个字符进行比较。因为B与A不匹配，所以搜索词后移一位。

2. ![2018-09-07-bg2013050104](https://ws3.sinaimg.cn/large/006tNc79ly1fz1lvlvvxfj30gs03tdfp.jpg)

   B与A不匹配，搜索词在往后移位。

3. ![2018-09-07-bg2013050105](https://ws1.sinaimg.cn/large/006tNc79ly1fz1lvqfkjhj30g103tmx1.jpg)

   一直往后移位，直到字符串有字符与搜索词第一个字符相同为止。

4. ![2018-09-07-bg2013050106](https://ws4.sinaimg.cn/large/006tNc79ly1fz1lvyfullj30g803ejr9.jpg)

   然后再比较搜索词下一个字符和字符串下一个字符是否相同，以此类推，直到完全匹配或者匹配到字符不相同为止。

5. ![2018-09-07-bg2013050107](https://ws2.sinaimg.cn/large/006tNc79ly1fz1lw51eb8j30g103ma9x.jpg)

   哈哈哈哈哈哈，巧了，这里匹配到最后刚好搜索词最后一个字符和字符串不匹配。

   那该怎么办呢？是像之前那样一位一位的算，还是有别的什么方法？🧐

   要是像之前那样，将搜索词后移一位，再逐个比较，虽然可行，只是效率极差，因为你要把“**搜索位置**”移到之前已经比较过的位置上再比一遍。

   你要学聪明点

6. ![2018-09-07-bg2013050107](https://ws3.sinaimg.cn/large/006tNc79ly1fz1lwncz3oj30g103ma9x.jpg)

   一个基本事实是，当空格与D不匹配时，你其实知道前面六个字符是“ABCDAB”。KMP算法的想法是，设法利用这个已知的信息，不要把**搜索位置**移回已经比较过的位置上。继续把它向后移(这里的向后移不是简单地向后移噢~)，这样就提高了效率。

7. ![2018-09-07-bg2013050109](https://ws1.sinaimg.cn/large/006tNc79ly1fz1lwvary5j30hx059q2w.jpg)

   这是一张叫做《部分匹配表》的表格，它是由搜索词而来。

   下面讲一下如何使用它，它是如何产生的待会再介绍。

8. ![2018-09-07-bg2013050107](https://ws3.sinaimg.cn/large/006tNc79ly1fz1lxfh7lgj30g103ma9x.jpg)

   还是这幅图- -，**由图可知**，空格与D不匹配，前面6个是匹配的。查表可知，最后一个字符B对应的“部分匹配值”为2，因此”搜索词“按照公式计算，向后移动4位：
   
   移动位数 = 已匹配的的字符数 - 对应的部分匹配值
   
   因为6-2=4，所以搜索词向后移4位。

9. ![2018-09-08-bg2013050110](https://ws2.sinaimg.cn/large/006tNc79ly1fz1lxr62azj30g503tdfp.jpg)

   移动完4位后，*是否从头开始再逐一匹配呢？或者可不可以直接从第三位开始匹配呢？*，空格和C不匹配，由公式得：2-0=2，得到下图：

10. ![2018-09-08-bg2013050111](https://ws3.sinaimg.cn/large/006tNc79ly1fz1lxvb9h0j30ft03sglh.jpg)

    空格与A不匹配，向后移一位。

11. ![2018-09-08-bg2013050112](https://ws3.sinaimg.cn/large/006tNc79ly1fz1ly0d5yij30ge03yjr9.jpg)

    逐位比较，C与D不匹配。于是，移动位数6-2=4。

12. ![2018-09-08-bg2013050113](https://ws3.sinaimg.cn/large/006tNc79ly1fz1ly5mfaxj30g003r745.jpg)

    逐位比较，直到搜索词的最后一位，发现完全匹配，于是搜索完成。

    若还想移动，(找出全部匹配)，移动位数=7-0，再将搜索词向后移动7位。以此类推。

## 四.部分匹配值表

1. ![2018-09-08-142526](https://ws4.sinaimg.cn/large/006tNc79ly1fz1lyk6xpbj30fb05mweg.jpg)

   介绍部分匹配表如何产生的前需要了解两个概念：前缀  后缀 

   前缀：除了最后一个字符以外，一个字符串的全部头部组合

   后缀：除了第一个字符以外，一个字符串的全部尾部组合

2. ![2018-09-08-144857](https://ws4.sinaimg.cn/large/006tNc79ly1fz1lyppfctj30hx059q2w.jpg)

   部分匹配值就是：

   > 前缀和后缀的最长共有元素长度~~~~！

   **A**的前缀和后缀都为空集，共有元素的长度为0；

   **AB**的前缀为{A}，后缀为{B}，共有元素的长度为0；

   **ABC**的前缀为{A，AB}，后缀为{C，BC}，共有元素的长度为0；

   **ABCD**的前缀为{A，AB，ABC}，后缀为{D，CD，BCD}，共有元素的长度为0；

   **ABCDA**的前缀为{A，AB，ABC，ABCD}，后缀为{A，DA，CDA，BCDA}，共有元素的长度为1；

   **ABCDAB**的前缀为{A，AB，ABC，ABCD，ABCDA}，后缀为{B，AB，DAB，CDAB，BCDAB}，共有元素的长度为2；

   **ABCDABD**的前缀为{A，AB，ABC，ABCD，ABCDA，ABCDAB}，后缀为{D，BD，ABD，DABD，CDABD，BCDABD}共有元素的长度为0；

   PS：共有元素长度为2的时候，6-2=4，向后移4位，然后是否可以从第三位开始逐一比较呢？因为由前面已知存在共有元素，长度为2❓❓

3. ![2018-09-09-031156](https://ws2.sinaimg.cn/large/006tNc79ly1fz1lyz1qi2j30ge03yjr9.jpg)

   总结：“部分匹配**值**”的实质是，有时候，搜索词的头部和尾部会有重复。比如，“ABCDAB”之中有两个AB，那么他的部分匹配值就是2。然后运用公式，将第一个AB向后移动4位(字符串长度-部分匹配值)，就可以来到第二个“AB”的位置。

   完。

