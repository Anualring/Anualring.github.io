# 语法

## lambda用法

一个表达式，比`def`定义的还简单

用法是在`lambda`中封装有限的逻辑进去

## range用法

## slim.arg_scope用法

> slim.arg_scope它的实现调用了两个语法，**修饰器**和**上下文管理器**

